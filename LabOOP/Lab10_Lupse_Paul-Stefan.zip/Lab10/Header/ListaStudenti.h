#ifndef LAB3_STIVA_H
#define LAB3_STIVA_H

#include "Student.h"

class Nod;

class ListaStudentiOrdonata;
// clasa care implementeaza o lista dublu inlantuita pentru tipul Studenti
class ListaStudenti{

    // clasa folosita pentru implementarea listei dublu inlantuite
protected:
    class Nod {

        StudentCNP* date;
        Nod *next, *prev;

    public:

        // constructor default
        Nod():date(new StudentCNP()),next(nullptr),prev(nullptr){};
        // constructor de copiere
        Nod(const Nod& other):
            date(new StudentCNP(*other.date)),
            next(nullptr),
            prev(nullptr){};

        explicit Nod(StudentCNP* student):date(new StudentCNP(*student)),next(nullptr),prev(nullptr){};

        ~Nod();

        // returneaza datele memorate de nod
        StudentCNP* get_date()const{return date;}

        // seteaza datele nodului
        void set_date(StudentCNP *student){date = student;}

        friend class ListaStudenti;
        friend class ListaStudentiOrdonata;
        friend ostream& operator<<(ostream&, ListaStudenti&);
        friend ostream& operator<<(ostream&, ListaStudentiOrdonata&);
    };

    Nod *baza, *varf;
    int nrNoduri;

    // folosita la quicksort
    Nod* partitie(Nod*, Nod*, bool (*)(StudentCNP*, StudentCNP*));
    void quicksort(Nod*, Nod*, bool (*)(StudentCNP*, StudentCNP*));

    // interschimba doua obiecte de tip student
    static void swap_studenti(StudentCNP*&, StudentCNP*&);

public:

    ListaStudenti():baza(nullptr),varf(nullptr),nrNoduri(0){};
    explicit ListaStudenti(string nume_fisier);
    ListaStudenti(const ListaStudenti & other);
    ~ListaStudenti();

    void adaugaVarf(StudentCNP * student);
    void adaugaBaza(StudentCNP * student);

    void eliminaVarf();
    void eliminaBaza();

    // extrage un varf din capatul listei
    StudentCNP* extrageVarf() const;

    // extrage un varf de la inceputul listei
    StudentCNP* extrageBaza() const;

    void afiseaza() const;
    // sterge dupa nume
    void sterge(string);
    // sorteaza folosind bubblesort
    void sorteaza(bool (*)(StudentCNP*, StudentCNP*));
    // sorteaza folosind quicksort
    void sorteazaQ(bool (*)(StudentCNP*, StudentCNP*));

    int lungime()const{return nrNoduri;};

    StudentCNP*& operator[](int index);
    ListaStudenti operator+(ListaStudenti&);
    ListaStudenti operator-(ListaStudenti&);
    ListaStudenti& operator=(ListaStudenti);

    friend ostream& operator<<(ostream&, ListaStudenti&);
};

class ListaStudentiOrdonata:public ListaStudenti {

public:
    bool (*comparator)(StudentCNP*, StudentCNP*);

    // constructor default
    ListaStudentiOrdonata():ListaStudenti(),comparator(&StudentCNP::compMedia){};

    explicit ListaStudentiOrdonata(bool (*_comparator)(StudentCNP*, StudentCNP*)):
        ListaStudenti(),comparator(_comparator){};
    explicit ListaStudentiOrdonata(string nume_fisier, bool (*_comparator)(StudentCNP*, StudentCNP*)):
        ListaStudenti(nume_fisier),comparator(_comparator){sorteazaQ(_comparator);};

    // constructor de copiere
    ListaStudentiOrdonata(const ListaStudentiOrdonata & other):ListaStudenti(other),comparator(other.comparator){};

    ~ListaStudentiOrdonata(){ListaStudenti::~ListaStudenti();};

    void adauga(StudentCNP* student);
    void adaugaVarf(StudentCNP * student);
    void adaugaBaza(StudentCNP * student);

    ListaStudentiOrdonata& operator=(ListaStudentiOrdonata);

    friend ostream& operator<<(ostream&, ListaStudentiOrdonata&);
};

#endif //LAB3_STIVA_H