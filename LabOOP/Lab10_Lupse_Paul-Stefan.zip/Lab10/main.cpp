#include "Student.h"
#include "ListaStudenti.h"
#include <iostream>
#include <Windows.h>
using namespace std;

int main() {
    SetConsoleOutputCP(CP_UTF8);

    auto *ls = new ListaStudenti("studenti2.txt");
    auto *lso = new ListaStudentiOrdonata("studenti1.txt",&StudentCNP::compMedia);

    for (int i = 0; i < ls->lungime(); i ++)
        lso->adaugaVarf((*ls)[i]);

    cout<<*lso;

    delete lso;
    delete ls;
    return 0;
}