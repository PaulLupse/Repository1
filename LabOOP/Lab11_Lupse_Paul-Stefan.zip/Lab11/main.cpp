#include "Student.h"
#include "ListaStudenti.h"
#include <iostream>
#include <Windows.h>
using namespace std;

int main() {
    SetConsoleOutputCP(CP_UTF8);

    auto *lso = new ListaStudentiOrdonata("studenti1.txt",&Student::compMedia);

    cout<<*lso;

    delete lso;
    return 0;
}