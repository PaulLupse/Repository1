#ifndef LAB1_SORTING_H
#define LAB1_SORTING_H

void bubble_sort(int* v, int n);
void selection_sort(int* v, int n);
void quick_sort(int* v, int n);

#endif