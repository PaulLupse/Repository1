#include "Student.h"
#include "ListaStudenti.h"
#include "TabStudenti.h"
#include <iostream>
#include <Windows.h>
using namespace std;

int main() {
    SetConsoleOutputCP( CP_UTF8 );

    TabStudenti ts("studenti.txt");
    ListaStudenti ls;

    for (int i = 0; i < ts.getN(); i++) {
        ls.adaugaVarf(ts[i]);
    }

    cout<<"\nAm citit " << ls.lungime() << " studenti:"<<'\n';
    cout<<ls;

    cout<<"\nQuickSort Studentii sortati alfabetic:"<<'\n';
    ls.sorteazaQ(Student::compNume);
    cout<<ls;

    cout<<"\nQuickSort Studentii sortati dupa medii:"<<'\n';
    ls.sorteazaQ(Student::compMedia);
    cout<<ls;

    cout<<"\nBubbleSort Studentii sortati alfabetic:"<<'\n';
    ls.sorteaza(Student::compNume);
    cout<<ls;

    cout<<"\nBubbleSort Studentii sortati dupa medii:"<<'\n';
    ls.sorteaza(Student::compMedia);
    cout<<ls;

    return 0;
}