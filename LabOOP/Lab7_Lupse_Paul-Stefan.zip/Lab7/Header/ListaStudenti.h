#ifndef LAB3_STIVA_H
#define LAB3_STIVA_H

#include "Student.h"

class Nod;

// clasa care implementeaza o lista dublu inlantuita pentru tipul Studenti
class ListaStudenti{

    // clasa folosita pentru implementarea listei dublu inlantuite
    class Nod {

        Student* date;
        Nod *next, *prev;

    public:

        // constructor default
        Nod():date(new Student()),next(nullptr),prev(nullptr){};
        // constructor de copiere
        Nod(const Nod& other):
            date(other.date),
            next(nullptr),
            prev(nullptr){};

        explicit Nod(Student* student):date(student),next(nullptr),prev(nullptr){};

        ~Nod();

        // returneaza datele memorate de nod
        Student* get_date()const{return date;}

        // seteaza datele nodului
        void set_date(Student *student){date = student;}

        friend class ListaStudenti;
        friend ostream& operator<<(ostream&, ListaStudenti&);
    };

    Nod *baza, *varf;
    int nrNoduri;

    // folosita la quicksort
    Nod* partitie(Nod*, Nod*, bool (*)(Student*, Student*));
    void quicksort(Nod*, Nod*, bool (*)(Student*, Student*));

    // interschimba doua obiecte de tip student
    static void swap_studenti(Student*&, Student*&);

public:

    ListaStudenti():baza(nullptr),varf(nullptr),nrNoduri(0){};
    explicit ListaStudenti(string nume_fisier);
    ListaStudenti(const ListaStudenti & other);
    ~ListaStudenti();

    void adaugaVarf(Student * student);
    void adaugaBaza(Student * student);

    void eliminaVarf();
    void eliminaBaza();

    // extrage un varf din capatul listei
    Student* extrageVarf() const;

    // extrage un varf de la inceputul listei
    Student* extrageBaza() const;

    void afiseaza() const;
    // sterge dupa nume
    void sterge(string);
    // sorteaza folosind bubblesort
    void sorteaza(bool (*)(Student*, Student*));
    // sorteaza folosind quicksort
    void sorteazaQ(bool (*)(Student*, Student*));

    int lungime()const{return nrNoduri;};

    Student*& operator[](int index);
    ListaStudenti& operator+(ListaStudenti);
    ListaStudenti& operator-(ListaStudenti&);

    friend ostream& operator<<(ostream&, ListaStudenti&);
};

#endif //LAB3_STIVA_H