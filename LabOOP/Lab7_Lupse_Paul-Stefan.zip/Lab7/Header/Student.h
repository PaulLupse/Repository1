#ifndef LAB3_STUDENT_H
#define LAB3_STUDENT_H

#include <string>
#include <iostream>
using namespace std;

// clasa ce memoreaza datele despre un student
class Student{

    string nume_complet, spec;
    int an;
    float media;

public:

    // constructor default
    Student():
        an(0),
        media(0.0f){};

    Student(const string& _nume_complet, const string& _specializare,const int& _an, const float& _media):
        nume_complet(_nume_complet),
        spec(_specializare),
        an(_an),
        media(_media){};

    Student(const Student& other):
        nume_complet(other.nume_complet),
        spec(other.spec),
        an(other.an),
        media(other.media){};

    string get_nume_complet() const {
        return nume_complet;
    }

    static bool compNume(Student *, Student *);
    static bool compMedia(Student *, Student *);

    void afiseaza();
    friend class TabStudenti;
    friend class ListaStudenti;
    friend class Nod;

    friend inline ostream& operator<<(ostream&, const Student&);
    friend ostream& operator<<(ostream&, Student*);
};


#endif //LAB3_STUDENT_H