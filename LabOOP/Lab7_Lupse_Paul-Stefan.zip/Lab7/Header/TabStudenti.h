//
// Created by Paul on 30-Oct-25.
//

#ifndef LAB4_TABSTUDENT_H
#define LAB4_TABSTUDENT_H

#include <Student.h>

class TabStudenti{

    int n; //numărul de studenți
    Student ** studenti; //pointer către tabloul de studenți
    int partitie(int, int, bool (*)(Student*, Student*)); //pentru quicksort
    void quicksort(int, int, bool (* comparator)(Student*, Student*));

    void swap_studenti(int, int);

public:

    explicit TabStudenti(string);//citeste datele din fișierul al cărui nume e specificat prin parametru
    ~TabStudenti();

    int getN() const {return n;}; //returnează numărul de studenți
    void afiseaza();
    void sorteaza(bool (*)(Student*, Student*));
    void sorteazaQ(bool (*)(Student*, Student*));

    Student*& operator[](int);

    friend ostream& operator<<(ostream&, TabStudenti&);

};

#endif //LAB4_TABSTUDENT_H