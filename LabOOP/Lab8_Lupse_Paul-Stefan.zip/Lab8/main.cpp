#include "Student.h"
#include "ListaStudenti.h"
#include <iostream>
#include <Windows.h>
using namespace std;

int main() {
    SetConsoleOutputCP(CP_UTF8);

    ListaStudenti ls1("studenti1.txt"), ls2("studenti2.txt");

    ListaStudenti ls3;

    ls3 = ls1 - ls2;

    cout<<ls3;

    return 0;

}